<?php
/**
 * Single Tour Page Template
*/
/**
 * Created by PhpStorm.
 * User: katwalsmacbookpro
 * Date: 1/30/18
 * Time: 12:51 PM
 */

get_header();



    if(have_posts()) {
        while (have_posts()):the_post();
            $postid = get_the_ID();
            $post_name=get_post();
            $post_title=get_the_title();
            $discount_rate = get_field('discount_rate', $postid);
            $duration = get_field('duration', $postid);
            $min_price = get_field('price_per_person', $postid);
            $overview = get_the_content();
            $itenary = get_field('itenary', $postid);
            $gallery = acf_photo_gallery('gallery', $postid);
            $brief = get_the_excerpt($postid);
            $field = get_field_object('location', $postid);
            $value = $field['value'];
            $location = $value->name;
            $max_people=get_field('max_people',$postid);
            $included=get_field('trip_included');
            $excluded=get_field('trip_excluded');
            $departure_content=get_field('fixed_departure_content');


            ?>

<!--            <script src="https://code.jquery.com/jquery-3.3.1.min.js"-->
<!--                    integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8="-->
<!--                    crossorigin="anonymous"></script>-->

            <div class="slideshow">
                <section class="hero-offer js-prevent-cookie" id="gallery">

                    <picture class="hero-image">

                        <!-- <img class="b-lazy" src="http://thrillhimalaya.com/uploads/packages/1515260214_jain-pilgrimage-in-india.jpg" data-src="http://thrillhimalaya.com/uploads/packages/1515260214_jain-pilgrimage-in-india.jpg">-->
                        <img style="max-height:100%;" src=" <?php the_post_thumbnail_url(); ?>">

                    </picture>

                    <div class="hero-offer__badge-wrapper "></div>
                </section>
            </div>

            <!-- tab sections -->
            <section class="page-width">
            <!-- Left Side Content -->
            <section class="inner_content_main">
            <!-- Package Detail Focused Overview -->
            <section class="offer-block offer-block--title card-title ">
            <!-- Expired offer-->
            <div class="offer-block__wrapper">
                <ul class="offer-icons offer-icons--large">
                    <li class="offer-icons__item js-tooltip tooltip" data-tooltip-cache="false">
                        <svg class="offer-icons__icon">
                            <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#airplane"></use>
                        </svg>
                        <span class="tooltip__content js-tooltip-content">
                               <font style="vertical-align: inherit;">
                                   <font style="vertical-align: inherit;">Flights included</font>
                               </font>
                           </span>
                    </li>
                    <li class="offer-icons__item js-tooltip tooltip" data-tooltip-cache="false">
                        <svg class="offer-icons__icon">
                            <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#hotel"></use>
                        </svg>
                        <span class="tooltip__content js-tooltip-content">
                               <font style="vertical-align: inherit;">
                                   <font style="vertical-align: inherit;">Accommodation included</font>
                               </font>
                           </span>
                    </li>
                </ul>

                <div class="card-title__wrapper">
                    <div class="card-title__summary ">
                        <h1 class="card-title__title">
                            <font style="vertical-align: inherit;">
                                <font style="vertical-align: inherit;"><?php the_title();?></font>
                            </font>
                        </h1>
                        <ul class="list list--horizontal">
                            <li class="list__item">
                                <font style="vertical-align: inherit;">
                                    <font style="vertical-align: inherit;">Citytrip</font>
                                </font>
                            </li>
                            <li class="list__item">
                                <font style="vertical-align: inherit;">
                                    <font style="vertical-align: inherit;"><?php echo $duration?></font>
                                </font>
                            </li>
                            <li class="list__item">
                                <font style="vertical-align: inherit;">
                                    <font style="vertical-align: inherit;"><?php $location?></font>
                                </font>
                            </li>
                        </ul>

                        <!-- Reviews -->
                        <div class="card-title__reviews-labels"></div>
                    </div>
                    <div class="card-title__price">
                        <div class="card-title__per-person">
                                <span class="card-title__price-per-person">
                                    <font style="vertical-align: inherit;">
                                        <font style="vertical-align: inherit;">from </font>
                                    </font>
                                </span>
                            <strong class="card-title__price-number">
                                <font style="vertical-align: inherit;">
                                    <font style="vertical-align: inherit;">NRS <?php echo $min_price;?></font>
                                </font>
                            </strong>
                            <span class="card-title__price-info">
                                        <span class="price-info tooltip js-tooltip price-info--large"
                                              data-bi-event="extra_info_tooltip"
                                              data-tooltip-url="/offer/105214/extra_info/?show_price_for_interval=1"
                                              data-tooltip-cache="false">
                                            <svg class="price-info__icon">
                                                <use xmlns:xlink="http://www.w3.org/1999/xlink"
                                                     xlink:href="#info"></use>
                                            </svg>
                                            <span class="tooltip__content js-tooltip-content"></span>
                                        </span>
                                    </span>
                        </div>
                        <ul class="list list--horizontal list--small">
                            <li class="list__item">
                                <font style="vertical-align: inherit;">
                                    <font style="vertical-align: inherit;">per person</font>
                                </font>
                            </li>
                            <li class="list__item">
                                <font style="vertical-align: inherit;">
                                    <font style="vertical-align: inherit;">
                                        max people <?php echo $max_people;?>
                                    </font>
                                </font>
                            </li>
                        </ul>

                        <div class="card-title__buttons">
                                <span class="card-title__button-share">
                                <div class="social-share js-socialShare social-share__toggle"
                                     data-event-action="Shared Offer Page">
    <h3 class="social-share__main-title">
        <font style="vertical-align: inherit;">
            <font style="vertical-align: inherit;">Share this trip</font>
        </font>
    </h3>
    <ul class="social-share__list social-share--hide-text">
        <li class="social-share__item" data-service="email">
            <a href="#" class="social-share__btn" data-utm-source="email" data-utm-medium="message"
               data-utm-campaign="offer-share">
                <svg class="social-share__icon">
                    <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-email"></use>
                </svg>
                <span class="social-share__title">E-mail</span>
            </a>
        </li>
        <li class="social-share__item  social-share--desktop-only" data-service="facebook-feed">
            <a href="#" class="social-share__btn" data-utm-source="facebook" data-utm-medium="social-media"
               data-utm-campaign="offer-share">
                <svg class="social-share__icon">
                    <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-facebook"></use>
                </svg>
                <span class="social-share__title">Facebook</span>
            </a>
        </li>
        <li class="social-share__item  social-share--desktop-only" data-service="messenger">
            <a href="#" class="social-share__btn" data-utm-source="messenger" data-utm-medium="message"
               data-utm-campaign="offer-share">
                <svg class="social-share__icon">
                    <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-messenger"></use>
                </svg>
                <span class="social-share__title">Messenger</span>
            </a>
        </li>
        <li class="social-share__item  social-share--desktop-only" data-service="twitter">
            <a href="#" class="social-share__btn" data-utm-source="twitter" data-utm-medium="social-media"
               data-utm-campaign="offer-share">
                <svg class="social-share__icon">
                    <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-twitter"></use>
                </svg>
                <span class="social-share__title">Twitter</span>
            </a>
        </li>
        <li class="social-share__item" data-service="whatsapp">
            <a href="#" class="social-share__btn" data-utm-source="whatsapp" data-utm-medium="message"
               data-utm-campaign="offer-share">
                <svg class="social-share__icon">
                    <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-whatsapp"></use>
                </svg>
                <span class="social-share__title">Whatsapp</span>
            </a>
        </li>
        <li class="social-share__item" data-service="sms">
            <a href="#" class="social-share__btn" data-utm-source="sms" data-utm-medium="message"
               data-utm-campaign="offer-share">
                <svg class="social-share__icon">
                    <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-sms"></use>
                </svg>
                <span class="social-share__title">SMS</span>
            </a>
        </li>
        <li class="social-share__item" data-service="messenger-app">
            <a href="#" class="social-share__btn" data-utm-source="messenger-app" data-utm-medium="message"
               data-utm-campaign="offer-share">
                <svg class="social-share__icon">
                    <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-messenger"></use>
                </svg>
                <span class="social-share__title">Messenger</span>
            </a>
        </li>
    </ul>
    <div class="social-share__url">
        <input class="social-share__url-field js-socialShareUrlField" type="text"
               value="http://fr.travelbird.be/105214/hotel-six-inn-budapest-hongrie/?utm_source=copy-url&amp;utm_medium=message&amp;utm_campaign=offer-share"
               readonly="">
    </div>
</div>
                                    <span class="social-share__toggler"><svg class="social-share__share-icon">
                                            <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#share"></use>
                                        </svg>
                                    </span>
                                </span>
                            <span class="card-title__button-like">
                                <span class="js-button-favorite" data-offer-id="105214"
                                      data-favorited="0" data-shape="offerpage">
                                <button data-reactroot="" class="button-favorite button-favorite--large">
                                    <svg class="button-favorite__icon">
                                        <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#heart"></use></svg>
                                    <svg class="button-favorite__icon button-favorite__icon--overlay">
                                        <use xmlns:xlink="http://www.w3.org/1999/xlink"
                                             xlink:href="#heart-border"></use>
                                    </svg>
                                </button>
                                </span>
                                </span>
                            <span class="card-title__button-book">
                                    <a href="#offer_calendar" class="button button--yellow"
                                       data-scroll="" data-event-category="Link clicks"
                                       data-event-action="Book now click" data-event-label="">
                                       <font style="vertical-align: inherit;">
                                           <font style="vertical-align: inherit;">Book</font></font></a>
                                </span>
                        </div>
                        <span class="card-title__booking-count">
                                    <font style="vertical-align: inherit;"><font style="vertical-align: inherit;">
                                    Already booked </font></font>
                                    <strong class="card-title__booking-count-number">
                                        <font style="vertical-align: inherit;">
                                            <font style="vertical-align: inherit;">8</font>
                                        </font>
                                    </strong>
                                    <font style="vertical-align: inherit;">
                                        <font style="vertical-align: inherit;"> times</font>
                                    </font>
                                </span>
                    </div>
                </div>
            </div>








                <section class="offer-block offer-block--gallery ">
                <div class="offer-block__wrapper">
                    <div class="js-Gallery Gallery gallery">
                        <ul class="imageGallery-lightbox js-Gallery__list Gallery__list">
                            <?php foreach($gallery as $image ):
                                $id = $image['id']; // The attachment id of the media
                                $title = $image['title']; //The title
                                $caption= $image['caption']; //The caption
                                $ful_image_url= $image['full_image_url']; //Full size image url
                                $full_image_url = acf_photo_gallery_resize_image($ful_image_url, 262, 160); //Resized size to 262px width by 160px height image url
                                $thumbnail_image_url= $image['thumbnail_image_url']; //Get the thumbnail size image url 150px by 150px
                                $url= $image['url']; //Goto any link when clicked
                                $target= $image['target']; //Open normal or new tab
                                $alt = get_field('photo_gallery_alt', $id); //Get the alt which is a extra field (See below how to add extra fields)
                                $class = get_field('photo_gallery_class', $id); //Get the class which is a extra field (See below how to add extra fields)
                                ?>

                                <li>
                                    <a href="<?php echo $ful_image_url;?>" title="<?php echo $caption; ?>">
                                        <img src="<?php echo $full_image_url; ?>"
                                             title="<?php echo $title; ?>"
                                             data-image="<?php echo $full_image_url; ?>">
                                    </a>
                                </li>
                                <?php
                            endforeach;
                            ?>
                        </ul>
                    </div>
                </div>
            </section>

            </section>

            <section class="section">
                <ul class="category-list">
                    <li class="category" id="category-overview">
                        <a href="#flights" class="active">
                            <span style="vertical-align: inherit;">Trip Overview</span>
                        </a>
                    </li>
                    <li class="category" id="category-115000615685">
                        <a href="#!">
                            <span style="vertical-align: inherit;">Itinerary</span>
                        </a>
                    </li>
                    <li class="category" id="category-115000592269">
                        <a href="#!">
                            <span style="vertical-align: inherit;">Reviews</span>
                        </a>
                    </li>
                    <li class="category" id="category-201050111">
                        <a href="#!">
                            <span style="vertical-align: inherit;">FAQ's</span>
                        </a>
                    </li>
                    <li class="category" id="category-200980721">
                        <a href="#!">
                            <span style="vertical-align: inherit;">Bookings</span>
                        </a>
                    </li>
                    <li class="category" id="category-overview">
                        <a href="#!">
                            <span style="vertical-align: inherit;">Included</span>
                        </a>
                    </li>
                </ul>
            </section>

            <!-- tab content sections -->
            <section class="about-us">
                <!-- tab 1-->
                <section class="tab-contents-package offer-block offer-block--accommodation-card " data-track-offer-id="104418" data-track-item-id="116905" style="display: block;">
                    <div class="offer-block__wrapper">
                        <?php echo $overview;?>
                    </div>

                </section>


                <!-- tab2 -->
                <section class="tab-contents-package offer-block offer-block--accommodation-card " data-track-offer-id="104418" data-track-item-id="116905" style="display: none;">
                    <div class="offer-block__wrapper">
                        <?php echo $itenary;?>
                    </div>
                </section>

                <!-- tab 3 -->
                <section class="tab-contents-package" style="display: none;">
                    <div class="wrap">

						
<div id="TA_selfserveprop311" class="TA_selfserveprop">
<ul id="kwa7oym" class="TA_links Mwwd5NjlkrSC">
<li id="bAo6IReI" class="ykrOUsrAu78">
<a target="_blank" href="https://www.tripadvisor.com/"><img src="https://www.tripadvisor.com/img/cdsi/img2/branding/150_logo-11900-2.png" alt="TripAdvisor"/></a>
</li>
</ul>
</div>
<script async src="https://www.jscache.com/wejs?wtype=selfserveprop&amp;uniq=311&amp;locationId=10239059&amp;lang=en_US&amp;rating=true&amp;nreviews=5&amp;writereviewlink=true&amp;popIdx=true&amp;iswide=false&amp;border=true&amp;display_version=2"></script>

                       

                    </div>

                </section>

                <!-- tab 4 -->
                <section class="tab-contents-package offer-block offer-block--accommodation-card" data-track-offer-id="104418" data-track-item-id="116905" style="display: none;">
                    <div class="offer-block__wrapper">
                        <h2 class="offer-block__title">
                            <span class="offer-block__title-main">FAQ's</span>
                        </h2>
                    </div>
                    <?php if( have_rows('faqs') ): ?>


	<?php while( have_rows('faqs') ): the_row();

		// vars
		$question = get_sub_field('question');
		$answer = get_sub_field('answer');


		?>
                    <!--faq 1-->
                    <div class="offer-block__units faq-container">
                        <h4 class="offer-block__unit-title">
                           <span class="faq-plusSign-div">
                               <svg class="offer-block__title-icon faq-plus-sign">
                                   <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#plus-sign"></use>
                               </svg>
                           </span>
                            <span class="faq-minusSign-div">
                               <svg class="offer-block__title-icon faq-minus-sign" x="0px" y="0px" xml:space="preserve">
                                   <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#minus-sign"></use>
                               </svg>
                           </span>
                            <?php echo $question;?>
                        </h4>
                        <div class="offer-block__unit-content faq-answer"><p><?php echo $answer;?></p></div>
                    </div>
                    <?php
                    endwhile;
                    endif;
                    ?>

                </section>

                <!-- tab 5 -->
                <section class="tab-contents-package offer-block offer-block--accommodation-card " data-track-offer-id="104418" data-track-item-id="116905" style="display: none;">

                    <section class="section departure-section">
                        <ul class="departure-tab">
                            <li class="category">
                                <a href="#fixed-departure" class="active">
                                    <span style="vertical-align: inherit;">Fixed Departure</span>
                                </a>
                            </li>
                            <li class="category">
                                <a href="#!">
                                    <span style="vertical-align: inherit;">Custom Departure</span>
                                </a>
                            </li>
                        </ul>
                    </section>

                    <!-- departure tab 1 -->
                    <div class="offer-block__wrapper departure-tab-content" id="fixed-departure">
                        <?php if (!empty($departure_content)):?>
                        <div class="fixed-departure-description offer-block__description offer-block__description--short">
                            <p><?php echo $departure_content;?></p>
                        </div>
                        <?php endif;
                        if(have_rows('fixed_departure')):
                            while(have_rows('fixed_departure')):the_row();
                        $start_date=get_sub_field('');
                                $start_date=get_sub_field('start_date');
                                $end_date=get_sub_field('end_date');
                        ?>
                        <div class="departure-row-wrapper">
                            <div class="offer-block__wrapper fixed-departure-content-row">
                                <div class="fixed-departure-content-left">
                                    <h2 class="offer-block__title">
                                        <span class="offer-block__title-main"><?php echo date('F j, Y', strtotime($start_date));?> - <?php echo date('F j, Y', strtotime($end_date));?></span>
                                    </h2>
                                    <ul class="list list--horizontal">
                                        <li class="list__item"><?php echo $min_price;?></li>
                                        <li class="list__item">Guaranteed</li>
                                    </ul>
                                </div>
                                <div class="fixed-departure-content-right">
                                    <a href="#">Book Now</a>
                                </div>
                            </div>
                        </div>
                        <?php
                        endwhile;
                        endif;?>
                    </div>

                    <!-- departure tab 2 -->
                    <div class="offer-block__wrapper departure-tab-content" id="" style="display: none;">
                        <div class="tailor-trip-description offer-block__description offer-block__description--short">
                            <p>It is in the heart of the Isola 2000 ski resort, in the southern French Alps, that this friendly hotel has come to install its cozy rooms close to the ski slopes.On the program: a beautiful indoor swimming pool, a terrace with deck chairs to enjoy the sun, snowshoeing and a pleasant sauna, all on the slopes.It's simple: just leave the hotel to enter the ski area!</p>
                        </div>

                        <div id="js-contact-form__wrapper">
                            <h3 class="contact-info__headline"> Please fill in our tailor-made request form</h3>

                            <form action="#!" method="post" class="contact-form js-contact-form">
                                <div class="input-group input-group--contact ">
                                    <label class="contact-form__label" for="name">Your name</label>
                                    <input id="id_name" maxlength="100" name="name" placeholder="Dit navn" type="text" required="">
                                </div>
                                <div class="input-group input-group--contact ">
                                    <label class="contact-form__label" for="email">Your e-mail address</label>
                                    <input id="id_email" name="email" placeholder="Din emailadresse" type="text" required="">
                                </div>
                                <div class="input-group input-group--contact">
                                    <label class="contact-form__label" for="reference_number">booking number</label>
                                    <input class="reference" id="id_reference_number" name="reference_number" placeholder="Bookingnummer" type="text">
                                </div>
                                <div class="input-group input-group--contact"><!-- class name input-group--contact-phone -->
                                    <label class="contact-form__label" for="phone">phone number</label>
                                    <input id="id_reference_number" maxlength="100" name="phone" placeholder="Dit telefonnummer" type="text">
                                </div>
                                <div class="input-group input-group--contact ">
                                    <label class="contact-form__label" for="description">Fill out the information</label>
                                    <textarea cols="40" id="id_description" name="description" placeholder="Udfyld informationerne" rows="6" required=""></textarea>
                                </div>
                                <div class="input-group input-group--contact type_submit">
                                    <input type="submit" value="Send" class="input_type_submit">
                                </div>
                            </form>
                        </div>
                    </div>
                </section>


                <!-- tab 6 -->
                <section class="tab-contents-package offer-block offer-block--accommodation-card " data-track-offer-id="104418" data-track-item-id="116905" style="display: none;">
                    <div class="offer-block__wrapper">
                    <?php if(!empty($included)):?>
                        <h2>Included</h2>
                        <section>
                            <?php echo $included;?>
                        </section>
                        <?php endif;
                        if (!empty($excluded)):
                        ?>
                        <h2>Excluded</h2>
                        <section>
                        <?php echo $excluded;?>
                        </section>
                        <?php endif;?>
                    </div>
                </section>
            </section>
        </section>
            <?php
        endwhile;
    }
?>
        <!-- Right Side Content -->
        <div class="right_sidebar">
            <!-- right sidebar 1 -->
            <section class="right_sidebar__section right_sidebar__the-nest section__full-width">
                <div class="right_sidebar__section-inner">
                    <h2 class="right_sidebar__section-title">
                        Before Booking
                    </h2>
                    <?php
                    $args1= array(
                         'post_type'=>'before-booking-trip',

                    );
            $the_query =new WP_Query( $args1 );
            $befor_arr=array();
            if ( $the_query->have_posts() ) {
                echo '<ul>';
                while ( $the_query->have_posts() ):
                    $the_query->the_post();
                $post_object=get_field('tour_or_trek_type');
                echo $the_query->the_title();
                foreach ($post_object as $post_value):
                    $meta_postid= $post_value->ID;

                                    if($meta_postid==$postid):
            ?>
                                <a href="<?php echo the_permalink()?>"><li><?php echo the_title(); ?></li></a>
                                        </ul>
                    <?php
                                    endif;
                endforeach;

                endwhile;
                wp_reset_postdata();
            }
                    ?>

                </div>
            </section>

            <!-- right sidebar 2 -->
            <section class="right_sidebar__section right_sidebar__the-nest section__full-width">
                <div class="right_sidebar__section-inner">
                    <h2 class="right_sidebar__section-title">
                        Sidebar Title 2
                    </h2>
					
					
                    
                </div>
            </section>

            <!-- right sidebar 3 -->
            <section class="right_sidebar__section right_sidebar__the-nest section__full-width">
                <div class="right_sidebar__section-inner">
                    <h2 class="right_sidebar__section-title">
                        Sidebar Title 3
                    </h2>
                    <p class="right_sidebar__section-txt">
                        Located on the historic canals of Amsterdam.
                    </p>
                    <ul>
                        <a href="#!"><li>Package List 1</li></a>
                        <a href="#!"><li>Package List 2</li></a>
                        <a href="#!"><li>Package List 3</li></a>
                        <a href="#!"><li>Package List 4</li></a>
                        <a href="#!"><li>Package List 5</li></a>
                        <a href="#!"><li>Package List 6</li></a>
                        <a href="#!"><li>Package List 7</li></a>
                        <a href="#!"><li>Package List 8</li></a>
                        <a href="#!"><li>Package List 9</li></a>
                    </ul>
                </div>
            </section>

            <!-- right sidebar 4 -->
            <section class="right_sidebar__section right_sidebar__the-nest section__full-width">
                <div class="right_sidebar__section-inner">
                    <h2 class="right_sidebar__section-title">
                        Sidebar Title 4
                    </h2>
                    <p class="right_sidebar__section-txt">
                        Located on the historic canals of Amsterdam.
                    </p>
                    <ul>
                        <a href="#!"><li>Package List 1</li></a>
                        <a href="#!"><li>Package List 2</li></a>
                        <a href="#!"><li>Package List 3</li></a>
                        <a href="#!"><li>Package List 4</li></a>
                        <a href="#!"><li>Package List 5</li></a>
                        <a href="#!"><li>Package List 6</li></a>
                        <a href="#!"><li>Package List 7</li></a>
                        <a href="#!"><li>Package List 8</li></a>
                        <a href="#!"><li>Package List 9</li></a>
                    </ul>
                </div>
            </section>
        </div>
    </section>

</main>

<?php
get_footer();
?>
<script>
    /* image gallery lightbox */
    jQuery(document).ready(function($) {

        jQuery('.imageGallery-lightbox li a').simpleLightbox();
    });
    /* end of image gallery lightbox */

</script>


<style>

    .section__full-width{max-width:none;padding-left:0;padding-right:0}
    @media screen and (min-width:768px){
        .right_sidebar__section-txt{
            font-size:20px;line-height:1.5;letter-spacing:-.1px;
        }
        .right_sidebar__section-title{
            font-size:22px;line-height:1.25;letter-spacing:-.3px;margin:0 0 15px;
        }
        .right_sidebar__section,.right_sidebar__section-inner{
            padding:15px 10px;padding-left:10px;padding-right:10px;
        }
        .right_sidebar__section,.right_sidebar__section-inner{
            padding:15px 10px;padding-left:10px;padding-right:10px;
        }
        .right_sidebar h2{
            font-size:22px;line-height:1.5;letter-spacing:-.1px;margin:0 0 10px;
        }
    }
    @media screen and (min-width:1024px){
        .right_sidebar h2{
            font-size:22px;line-height:1.25;letter-spacing:-.5px;
        }
    }
    .faq-container{margin-left: 1%;margin-right:1%;margin-bottom:1%;width: 98%;padding:2%; }
    .faq-answer{margin-left: 4.8%;}
    .right_sidebar__section{
        border: 1px solid #e9e9eb;border-radius: 2px;
    }
    .right_sidebar h2,.about-us h3,.about-us h4{
        font-family:"Helvetica Neue", Arial, Helvetica, sans-serif;
    }
    .right_sidebar__section,.right_sidebar__section-inner{
        margin-left:auto;margin-right:auto;max-width:100%;padding:15px 10px;
    }
    .right_sidebar__section-title{
        font-size:22px;line-height:1.25;letter-spacing:-.2px;margin:0 0 10px;
    }
    .right_sidebar__section-txt{
        font-size:18px;line-height:1.5;letter-spacing:-.1px;margin:0 0 10px;
    }
    .right_sidebar__the-nest{
        background:#f4f4f5;color:#000;padding-top:0;padding-bottom:0;
    }
    .right_sidebar__section{
        margin-bottom: 4%;
    }
    .faq-minusSign-div,.faq-answer{display: none;}
    .faq-minusSign-div:hover,.faq-plusSign-div:hover{cursor: pointer;}
    .faq-answer:after{background:none;}
    .departure-section{margin-top:5%;margin-left:3%;margin-right:1%;}
    .departure-tab .category{width: 48.8%;}
    .departure-tab li .active{background: #27a9e1;font-weight: 600;color: #ffffff;}
    .departure-tab li a{background: #0a8de96e;}
    .departure-tab .category a:before{width: 0px;height: 0px;}
    .departure-tab .category a{height: 25px;padding: 25px 0px 25px 0px;}
    .fixed-departure-content-row{position: relative;}
    .fixed-departure-content-left{float: left;left: 0px;}
    .fixed-departure-content-left .offer-block__title{padding-top: 15px;}
    .fixed-departure-content-right{float: right;right: 0px;top:20px;position: absolute;margin-right: 10px;}
    .fixed-departure-content-right a {
        display: inline-block;
        padding: 15px 18px;
        background: #27A9E1;
        border: none;
        color: #FFFFFF;
        font-size: 14px;
        font-weight: normal;
        line-height: 16px;
        -moz-border-radius: 3px;
        -webkit-border-radius: 3px;
        border-radius: 3px;
        text-transform: uppercase;
        text-decoration: none;
        transition: all 0.1s ease-out;
    }
    .fixed-departure-content-right a:hover{
        background-color: #2295C7;
        color: #FFFFFF;
        text-decoration: none;
    }
    .offer-block--accommodation-card .offer-block__wrapper {
        padding: 0 30px 50px 30px;
        border-bottom: 0;
    }
    .departure-row-wrapper{max-height:1000px;overflow-y: scroll;}
    .offer-block__wrapper.fixed-departure-content-row{border-bottom:1px solid #cccccc;background:#ffffff;padding: 0px 20px;border-radius: 5px;}
    .fixed-departure-description,.tailor-trip-description{text-align: justify;margin-top: 2%;}
    .fixed-departure-description:after,.tailor-trip-description:after{background: none;}
    .type_submit{float: right;margin-top: 10px;}
    .input_type_submit{padding: 20px 50px;font-weight: 600;}
</style>


