(function($){
    "use strict"; // Start of use strict
    /*==============================
     Is mobile
     ==============================*/
    var isMobile = {
        Android: function() {
            return navigator.userAgent.match(/Android/i);
        },
        BlackBerry: function() {
            return navigator.userAgent.match(/BlackBerry/i);
        },
        iOS: function() {
            return navigator.userAgent.match(/iPhone|iPad|iPod/i);
        },
        Opera: function() {
            return navigator.userAgent.match(/Opera Mini/i);
        },
        Windows: function() {
            return navigator.userAgent.match(/IEMobile/i);
        },
        any: function() {
            return (isMobile.Android() || isMobile.BlackBerry() || isMobile.iOS() || isMobile.Opera() || isMobile.Windows());
        }
    };

    /*==============================
     end of Is mobile code
     ==============================*/

    $(document).ready(function() {
        /* image gallery lightbox */
        // $('.imageGallery-lightbox li a').simpleLightbox();
        /* end of image gallery lightbox */

        /* topbar sticky header */
        var fullHeaderHeight      = $('.header--Travelbird').outerHeight(true);
        var secondaryHeaderHeight = $('.secondary-menu').outerHeight(true);
        $(window).scroll(function() {
            var topHeaderHeight       = $('.top-header').outerHeight(true);
            var fullHeaderHeight      = $('.header--Travelbird').outerHeight(true);
            var secondaryHeaderHeight = $('.secondary-menu').outerHeight(true);
            if ($(this).scrollTop() > topHeaderHeight) {
                $('.breadcrumb').addClass('sticky');
                $('.nav-menu-overlay').css('top',secondaryHeaderHeight+8+"px");
            }
            else {
                $('.nav-menu-overlay').css('top',fullHeaderHeight+"px");
                $('.breadcrumb').removeClass('sticky');
            }
        });
        /* end of topbar sticky header */

        /* **secondary header ** navbar-2nd */
        headerMenuResize();
        $(window).resize(function (){
            headerMenuResize();
        });
        function headerMenuResize(){
            if($(window).outerWidth()>=1001){
                $('.primary-menu-li .nav-menu-dropdown').css({'padding':'4px 18px'});
                $('.primary-menu-ul').show();
                $('.nav-menu__hamburger-icon').css('display','none');
                $('.primary-menu-li').on('mouseover',function (){
                    //$('.nav-menu__sub-list-wrap').hide();
                    var subCategoryMenu       = $(this).find('.nav-menu__main-list').outerHeight(true);
                    $('.nav-menu__sub-list-wrap').css({'min-height':subCategoryMenu+"px"});
                    $(this).find('.nav-menu__main-list').show();
                    $(this).on('mouseout',function () {
                        $(this).find('.nav-menu__main-list').css("display","none");
                    });
                });
                $('.primary-menu-li .nav-menu__main-item').on('mouseover',function () {
                    $(".primary-menu-li .nav-menu__sub-list-wrap").css('display','none');
                    $(this).find('.nav-menu__arrow').css({'fill':'#3ab0e3'});
                    $(this).find(".nav-menu__sub-list-wrap").css('display','inline-block');
                });
                $('.primary-menu-li .nav-menu__main-item').on('mouseout',function (){
                    $(this).find('.nav-menu__arrow').css({'fill':'#000000'});
                });
            }else if($(window).outerWidth()<=1000 || isMobile.any()){
                $('.primary-menu-li .nav-menu-dropdown').css({'padding':'10px 16px 10px 6px'});
                $('.nav-menu__hamburger-icon,.unhide-menu').show();
                $('.hide-menu').hide();
                $('.primary-menu-ul').hide();
                $('.nav-menu__dropdown-title.main-nav-title').show();
                $('.unhide-menu').on('click',function () {
                    $('.primary-menu-ul').show();
                    $('.unhide-menu').hide(800);
                    $('.hide-menu').show(800);
                });
                $('.hide-menu').on('click',function () {
                    $('.primary-menu-ul').hide();
                    $('.hide-menu').hide(800);
                    $('.unhide-menu').show(800)
                });
            }
        }
        if($(window).outerWidth()>=1001){
            $('.primary-menu-li .nav-menu-dropdown').css({'padding':'4px 18px'});
        }
        /* end of editing header menu */

        /*  itinerary tab */
        $('.category-list a').click(function(){
            var $index = $(this).closest('li').index();
            $('.category-list a').removeClass('active');
            $('.category-list li').eq($index).find('a').addClass('active');
            $('.tab-contents-package').hide().eq($index).fadeIn();
            return false;
        });
        /* end of itinerary tab */

        /*  itinerary tab */
        $('.departure-tab a').click(function(){
            var $index = $(this).closest('li').index();
            $('.departure-tab a').removeClass('active');
            $('.departure-tab li').eq($index).find('a').addClass('active');
            $('.departure-tab-content').hide().eq($index).fadeIn();
            return false;
        });
        /* end of itinerary tab */

        /* faq */
        $('.faq-plusSign-div').click(function (){
            $(this).hide();
            $(this).parent('.offer-block__unit-title').find('.faq-minusSign-div').show();
            $(this).parents('.faq-container').find('.faq-answer').slideDown("slow");
        });
        $('.faq-minusSign-div').click(function () {
            $(this).hide();
            $(this).parent('.offer-block__unit-title').find('.faq-plusSign-div').show();
            $(this).parents('.faq-container').find('.faq-answer').slideUp("slow");
        });
        /*end of faq */
    });
})(jQuery);