<?php
/**
 * iceberg_travel functions and definitions
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package iceberg_travel
 */

if ( ! function_exists( 'iceberg_travel_setup' ) ) :
	/**
	 * Sets up theme defaults and registers support for various WordPress features.
	 *
	 * Note that this function is hooked into the after_setup_theme hook, which
	 * runs before the init hook. The init hook is too late for some features, such
	 * as indicating support for post thumbnails.
	 */
	function iceberg_travel_setup() {
		/*
		 * Make theme available for translation.
		 * Translations can be filed in the /languages/ directory.
		 * If you're building a theme based on iceberg_travel, use a find and replace
		 * to change 'iceberg_travel' to the name of your theme in all the template files.
		 */
		load_theme_textdomain( 'iceberg_travel', get_template_directory() . '/languages' );

		// Add default posts and comments RSS feed links to head.
		add_theme_support( 'automatic-feed-links' );

		/*
		 * Let WordPress manage the document title.
		 * By adding theme support, we declare that this theme does not use a
		 * hard-coded <title> tag in the document head, and expect WordPress to
		 * provide it for us.
		 */
		add_theme_support( 'title-tag' );

		/*
		 * Enable support for Post Thumbnails on posts and pages.
		 *
		 * @link https://developer.wordpress.org/themes/functionality/featured-images-post-thumbnails/
		 */
		add_theme_support( 'post-thumbnails' );

		// This theme uses wp_nav_menu() in one location.
		register_nav_menus( array(
			'menu-1' => esc_html__( 'Primary', 'iceberg_travel' ),
            'primary_menu'=>esc_html__('Top Header', 'iceberg_travel'),
            'secondary_menu'=> esc_html('Breadcumb _Header', 'iceber_travel'),
		) );

		/*
		 * Switch default core markup for search form, comment form, and comments
		 * to output valid HTML5.
		 */
		add_theme_support( 'html5', array(
			'search-form',
			'comment-form',
			'comment-list',
			'gallery',
			'caption',
		) );

		// Set up the WordPress core custom background feature.
		add_theme_support( 'custom-background', apply_filters( 'iceberg_travel_custom_background_args', array(
			'default-color' => 'ffffff',
			'default-image' => '',
		) ) );

		// Add theme support for selective refresh for widgets.
		add_theme_support( 'customize-selective-refresh-widgets' );

		/**
		 * Add support for core custom logo.
		 *
		 * @link https://codex.wordpress.org/Theme_Logo
		 */
		add_theme_support( 'custom-logo', array(
			'height'      => 250,
			'width'       => 250,
			'flex-width'  => true,
			'flex-height' => true,
		) );
	}
endif;
add_action( 'after_setup_theme', 'iceberg_travel_setup' );

/**
 * Set the content width in pixels, based on the theme's design and stylesheet.
 *
 * Priority 0 to make it available to lower priority callbacks.
 *
 * @global int $content_width
 */
function iceberg_travel_content_width() {
	$GLOBALS['content_width'] = apply_filters( 'iceberg_travel_content_width', 640 );
}
add_action( 'after_setup_theme', 'iceberg_travel_content_width', 0 );

/**
 * Register widget area.
 *
 * @link https://developer.wordpress.org/themes/functionality/sidebars/#registering-a-sidebar
 */
function iceberg_travel_widgets_init() {
	register_sidebar( array(
		'name'          => esc_html__( 'Sidebar', 'iceberg_travel' ),
		'id'            => 'sidebar-1',
		'description'   => esc_html__( 'Add widgets here.', 'iceberg_travel' ),
		'before_widget' => '<section id="%1$s" class="widget %2$s">',
		'after_widget'  => '</section>',
		'before_title'  => '<h2 class="widget-title">',
		'after_title'   => '</h2>',
	) );
}
add_action( 'widgets_init', 'iceberg_travel_widgets_init' );

/**
 * Enqueue scripts and styles.
 */
function iceberg_travel_scripts() {
	wp_enqueue_style( 'iceberg_travel-style', get_stylesheet_uri() );

	wp_enqueue_script( 'iceberg_travel-navigation', get_template_directory_uri() . '/js/navigation.js', array(), '20151215', true );

	wp_enqueue_script( 'iceberg_travel-skip-link-focus-fix', get_template_directory_uri() . '/js/skip-link-focus-fix.js', array(), '20151215', true );

	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}
    wp_enqueue_style('home-style',get_template_directory_uri().'/css/duck.css');
    wp_enqueue_style('home-style1',get_template_directory_uri().'/css/duckmain.css');
    wp_enqueue_style('home-stl',get_template_directory_uri().'/css/duck1.css');
    wp_enqueue_script('home-script4', get_template_directory_uri() . '/js/common.js');


    if(is_single()) {
        wp_enqueue_script('home-script1', 'https://code.jquery.com/jquery-3.3.1.min.js');
        wp_enqueue_style('home-style3', get_template_directory_uri() . '/css/simpleLightbox.css');
        wp_enqueue_script('home-script', get_template_directory_uri() . '/js/simpleLightbox.min.js');

    }
}
add_action( 'wp_enqueue_scripts', 'iceberg_travel_scripts' );

/**
 * Implement the Custom Header feature.
 */
require get_template_directory() . '/inc/custom-header.php';

/**
 * Custom template tags for this theme.
 */
require get_template_directory() . '/inc/template-tags.php';

/**
 * Functions which enhance the theme by hooking into WordPress.
 */
require get_template_directory() . '/inc/template-functions.php';

/**
 * Customizer additions.
 */
require get_template_directory() . '/inc/customizer.php';

/**
 * Load Jetpack compatibility file.
 */
if ( defined( 'JETPACK__VERSION' ) ) {
	require get_template_directory() . '/inc/jetpack.php';
}

/**
 * Load WooCommerce compatibility file.
 */
if ( class_exists( 'WooCommerce' ) ) {
	require get_template_directory() . '/inc/woocommerce.php';
}


/**
 * filter to choose template (Template Chooser)
 */

function template_chooser( $template ){
    global $wp_query;
    $post_type = get_query_var('post_type');
    if( $wp_query->is_search && $post_type == 'tour' ){
        return locate_template('archive-tour.php');  //  redirect to archive-search.php
    }  elseif($wp_query->is_search && $post_type='trekking'){
        return locate_template('archive-trekking.php');  //  redirect to archive-search.php

    }
    return $template;
}
add_filter( 'template_include', 'template_chooser' );

/**
 *  Search Result title filter
*/

function title_filter($where, &$wp_query){
    global $wpdb;
    if($search_term = $wp_query->get( 'title_filter' )){
        $search_term = $wpdb->esc_like($search_term); //instead of esc_sql()
        $search_term = ' \'%' . $search_term . '%\'';
        $title_filter_relation = (strtoupper($wp_query->get( 'title_filter_relation'))=='OR' ? 'OR' : 'AND');
        $where .= ' '.$title_filter_relation.' ' . $wpdb->posts . '.post_title LIKE '.$search_term;
    }
    return $where;
}
add_filter('posts_where','title_filter',10,2);

/**
 * Require items
*/
 require_once get_template_directory().'/inc/custom-post-type.php';
 require_once  get_template_directory().'/inc/custom-taxonomy.php';



