 <div class="usp-list">
            <form role="search" method="get" id="searchform" class="tour-searchform" action="<?php echo esc_url( home_url( '/' ) ); ?>">
                <ul class="usp-list__list">
                    <?php if(is_home() || is_front_page()) { ?>
                        <li class="">
                            <label style="margin-right:2%;"><?php _e('Trip Type') ?></label>
                            <select name="post_type" class="full-width">
                                <option value="tour"><?php _e('Tour') ?></option>
                                <option value="trekking"><?php _e('Trekking') ?></option>
                            </select>
                        </li>
                        <?php
                    }
                    ?>
                    <?php if(!is_home() || !is_front_page()) {
                        if (is_post_type_archive(tour)) {
                            ?>
                            <input type="hidden" name="post_type" value="tour">
                            <li>
                            <label style="margin-right:2%;"><?php _e('Country') ?></label>
                            <select name="country" class="full-width">
                                <option value="">Select</option>
                                <?php
                                $terms = get_terms( array(
                                    'taxonomy' => 'location',
                                    'hide_empty' => true,
                                ) );
                                foreach ($terms as $categories): ?>
                                <option value="<?php echo $categories->slug;?>"><?php echo $categories->name; ?></option>
                                <?php endforeach; ?>
                            </select>
                            </li>
                            <li>
                            <label style="margin-right:2%;"><?php _e('Activity') ?></label>
                            <select name="activity" class="full-width">
                                <option value="">Select</option>
                                <?php
                                $terms = get_terms( array(
                                    'taxonomy' => 'activity_tour',
                                    'hide_empty' => true,
                                ) );
                                foreach ($terms as $categories): ?>
                                    <option value="<?php echo $categories->slug;  ?>"><?php echo $categories->name; ?></option>
                                <?php endforeach; ?>
                            </select>
                            </li>
                            <?php
                        }
                        if (is_post_type_archive(trekking)) {
                            ?>
                            <input type="hidden" name="post_type" value="trekking">
                            <li>
                            <label style="margin-right:2%;"><?php _e('Country') ?></label>
                            <select name="country" class="full-width">
                                <option value="">Select</option>
                                <?php
                                $terms = get_terms( array(
                                    'taxonomy' => 'location',
                                    'hide_empty' => true,
                                ) );
                                foreach ($terms as $categories): ?>
                                    <option value="<?php echo $categories->slug ; ?>"><?php echo $categories->name; ?></option>
                                <?php endforeach; ?>
                            </select>
                            </li>
                            <li>
                            <label style="margin-right:2%;"><?php _e('Activity') ?></label>
                            <select name="activity" class="full-width">
                                <option value="">Select</option>
                                <?php
                                $terms = get_terms( array(
                                    'taxonomy' => 'activity_trekking',
                                    'hide_empty' => true,
                                ) );
                                foreach ($terms as $categories): ?>
                                    <option value="<?php echo $categories->slug;  ?>"><?php echo $categories->name; ?></option>
                                <?php endforeach; ?>
                            </select>
                            </li>
                        <?php }
                    }?>
                    <li class="">
                                <label style="margin-right:2%; margin-left:0%;"><?php _e( 'Destination ' ) ?></label>
                                <input size="25" type="text" name="s" class="input-text full-width" placeholder="<?php _e( 'Enter a destination name') ?>" />
                    </li>

                    <li class="">
                            <label class="hidden-xs">&nbsp;</label>
                            <span class="usp-list__text">
                                <button type="submit" class="full-width icon-check animated" data-animation-type="bounce" data-animation-duration="1"><?php _e( 'SEARCH NOW', 'trav') ?></button>
                            </span>
                    </li>
                </ul>
            </form>
        </div>



