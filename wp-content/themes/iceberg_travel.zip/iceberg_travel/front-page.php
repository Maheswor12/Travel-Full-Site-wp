<?php
/**
 * Created by PhpStorm.
 * User: katwalsmacbookpro
 * Date: 1/14/18
 * Time: 10:36
 * FrontPage template i.e home page
 */


get_header();
?>
<?php echo do_shortcode('[rev_slider alias="homepage"]');?>


        <?php
        //edited search start
        get_template_part('test_yk','single');

        //edited search end
        ?>
        <div class="usp-list">
            <ul class="usp-list__list">
                <li class="usp-list__item">
                    <a class="usp-list__link" href="#">
                        <svg class="usp-list__icon">
                            <use xlink:href="#check-circle" />
                        </svg>
                        <span class="usp-list__text">Travel with us</span>
                    </a>
                </li>
                <li class="usp-list__item">
                    <a class="usp-list__link" href="#">
                        <svg class="usp-list__icon">
                            <use xlink:href="#check-circle" />
                        </svg>
                        <span class="usp-list__text">Know the nature</span>
                    </a>
                </li>
                <li class="usp-list__item">
                    <a class="usp-list__link" href="#">
                        <svg class="usp-list__icon">
                            <use xlink:href="#check-circle" />
                        </svg>
                        <span class="usp-list__text">Enjoy with us</span>
                    </a>
                </li>
            </ul>
        </div>
        <section class="wrap homepage">
            <section class="countdown">
                <h2 class="countdown__title">
                    Best Offer Package
                </h2>
<!--                <p class="countdown__subtitle" id="timer" data-countdown='{"time": "midnight","format": "&lt;span&gt;%H timer %M minutter %S sekunder&lt;/span&gt; indtil næste udvalg"}'>&nbsp;</p>-->

            </section>

            <section class='grid grid--offer-cards-homepage'>
                <ul class="grid-cards__list">
                <?php
                $args=array(
                        'post_type'=>array('tour','trekking'),
                        'posts_per_page'=>'6',
                    'orderby'=>'discount_rate',
                    'order'=>'ASC'
                );
                $query=new WP_Query($args);
                if($query->have_posts()):
                    while($query->have_posts()):$query->the_post();
                        $postid=$query->post->ID;
                   $discount_rate = get_field( 'discount_rate', $postid );
                       $duration = get_field(  'duration',$postid );
                        $min_price = get_field( 'price_per_person', $postid );
                       $brief = get_the_excerpt($postid);
                        $field = get_field_object('location',$postid);
                       $value = $field['value'];
                       $location=$value->name;
                        if($discount_rate<=0){
                           // echo "No Offer package available";
                        }else {
//                        $city = trav_tour_get_city($postid);
//                        $country = trav_tour_get_country($postid);

                            ?>
                            <li class="grid-cards__item">


                                <a href="<?php the_permalink(); ?>" target="_self"
                                   class="offer-card" data-offer-id="106215" data-js-component="offerCard">

                                    <div data-src="<?php the_post_thumbnail_url(); ?>" class="offer-card__image b-lazy"
                                         style="background-image: url('<?php the_post_thumbnail_url(); ?>')">

                <span class="js-button-favorite" data-offer-id="106215" data-favorited="0" data-shape="offercard">
                   <button class="button-favorite">
                    <svg class="button-favorite__icon">
                       <use xlink:href="#heart"/>
                    </svg>
                    <svg class="button-favorite__icon button-favorite__icon--overlay">
                       <use xlink:href="#heart-border"/>
                    </svg>
                   </button>
                </span>

                                    </div>

                                    <div class="offer-card__info">
                                        <h4 class="offer-card__title"><?php the_title(); ?></h4>
                                        <ul class="list list--horizontal">

                                            <li class="list__item"><i
                                                        class="soap-icon-clock yellow-color"></i> <?php echo esc_html($duration); ?>
                                            </li>
                                            <!--                                    <li class="list__item"></li>-->
                                        </ul>
                                        <!--                                <ul class="offer-icons">-->
                                        <!--                                    <li class="offer-icons__item js-tooltip tooltip">-->
                                        <!--                                        <svg class="offer-icons__icon">-->
                                        <!--                                            <use xlink:href="#hotel" />-->
                                        <!--                                        </svg>-->
                                        <!--                                        <span class="tooltip__content js-tooltip-content">Med indkvartering</span>-->
                                        <!--                                    </li>-->
                                        <!--                                </ul>-->

                                        <div class="offer-card__price-wrap">
                                            <span class="offer-card__price-from">Price </span>
                                            <span class="offer-card__price-value">NPR.<?php echo $min_price; ?>-</span>
                                            <!--                                    <span class="price-info tooltip js-tooltip" data-bi-event="extra_info_tooltip"-->
                                            <!--                                          data-tooltip-url="/offer/106215/extra_info/?show_price_for_interval=1">-->
                                            <!--                    <svg class="price-info__icon">-->
                                            <!--                        <use xlink:href="#info" />-->
                                            <!--                    </svg>-->
                                            <span class="tooltip__content js-tooltip-content"></span>
                                            </span>
                                        </div>

                                        <ul class="list list--horizontal list--small">
                                            <li class="list__item">Cost per person</li>
                                            <li class="list__item"><?php echo $location; ?></li>
                                        </ul>
                                    </div>
                                </a>
                            </li>

                            <?php
                        }

                    endwhile;
                else :
                    ?>
                    <li class="grid-cards__item">

                        <h3>No Tours Available.</h3>

                    </li>
                    <?php
                    // Restore original Post Data
                    wp_reset_postdata();
                        endif;
                    ?>
                </ul>
            </section>
            <!--Tour List-->
            <section class="countdown">
                <h2 class="countdown__title">
                    Tours Package
                </h2>
                <!--                <p class="countdown__subtitle" id="timer" data-countdown='{"time": "midnight","format": "&lt;span&gt;%H timer %M minutter %S sekunder&lt;/span&gt; indtil næste udvalg"}'>&nbsp;</p>-->

            </section>

            <section class='grid grid--offer-cards-homepage'>
                <ul class="grid-cards__list">
                    <?php
                    $args=array(
                        'post_type'=>'tour',
                        'posts_per_page'=>'6',

                    );
                    $query=new WP_Query($args);
                    if($query->have_posts()):
                        while($query->have_posts()):$query->the_post();
                            $postid=$query->post->ID;
                            $discount_rate = get_field( 'discount_rate', $postid );
                            $duration = get_field(  'duration',$postid );
                            $min_price = get_field( 'price_per_person', $postid );
                            $brief = get_the_excerpt($postid);
                            $field = get_field_object('location',$postid);
                            $value = $field['value'];
                            $location=$value->name;


//                        $city = trav_tour_get_city($postid);
//                        $country = trav_tour_get_country($postid);

                                ?>
                                <li class="grid-cards__item">


                                    <a href="<?php the_permalink(); ?>" target="_self"
                                       class="offer-card" data-offer-id="106215" data-js-component="offerCard">

                                        <div data-src="<?php the_post_thumbnail_url(); ?>" class="offer-card__image b-lazy"
                                             style="background-image: url('<?php the_post_thumbnail_url(); ?>')">

                <span class="js-button-favorite" data-offer-id="106215" data-favorited="0" data-shape="offercard">
                   <button class="button-favorite">
                    <svg class="button-favorite__icon">
                       <use xlink:href="#heart"/>
                    </svg>
                    <svg class="button-favorite__icon button-favorite__icon--overlay">
                       <use xlink:href="#heart-border"/>
                    </svg>
                   </button>
                </span>

                                        </div>

                                        <div class="offer-card__info">
                                            <h4 class="offer-card__title"><?php the_title(); ?></h4>
                                            <ul class="list list--horizontal">

                                                <li class="list__item"><i
                                                            class="soap-icon-clock yellow-color"></i> <?php echo esc_html($duration); ?>
                                                </li>
                                                <!--                                    <li class="list__item"></li>-->
                                            </ul>
                                            <!--                                <ul class="offer-icons">-->
                                            <!--                                    <li class="offer-icons__item js-tooltip tooltip">-->
                                            <!--                                        <svg class="offer-icons__icon">-->
                                            <!--                                            <use xlink:href="#hotel" />-->
                                            <!--                                        </svg>-->
                                            <!--                                        <span class="tooltip__content js-tooltip-content">Med indkvartering</span>-->
                                            <!--                                    </li>-->
                                            <!--                                </ul>-->

                                            <div class="offer-card__price-wrap">
                                                <span class="offer-card__price-from">Price </span>
                                                <span class="offer-card__price-value">NPR.<?php echo $min_price; ?>-</span>
                                                <!--                                    <span class="price-info tooltip js-tooltip" data-bi-event="extra_info_tooltip"-->
                                                <!--                                          data-tooltip-url="/offer/106215/extra_info/?show_price_for_interval=1">-->
                                                <!--                    <svg class="price-info__icon">-->
                                                <!--                        <use xlink:href="#info" />-->
                                                <!--                    </svg>-->
                                                <span class="tooltip__content js-tooltip-content"></span>
                                                </span>
                                            </div>

                                            <ul class="list list--horizontal list--small">
                                                <li class="list__item">Cost per person</li>
                                                <li class="list__item"><?php echo $location; ?></li>
                                            </ul>
                                        </div>
                                    </a>
                                </li>

                                <?php
                        endwhile;
                    else :
                        ?>
                        <li class="grid-cards__item">

                            <h3>No Tours Available.</h3>

                        </li>
                        <?php
                        // Restore original Post Data
                        wp_reset_postdata();
                    endif;
                    ?>
                </ul>
            </section>

            <!--Trekking list-->

            <section class="countdown">
                <h2 class="countdown__title">
                    Trekking Package
                </h2>
                <!--                <p class="countdown__subtitle" id="timer" data-countdown='{"time": "midnight","format": "&lt;span&gt;%H timer %M minutter %S sekunder&lt;/span&gt; indtil næste udvalg"}'>&nbsp;</p>-->

            </section>

            <section class='grid grid--offer-cards-homepage'>
                <ul class="grid-cards__list">
                    <?php
                    $args=array(
                        'post_type'=>'trekking',
                        'posts_per_page'=>'6',
                    );
                    $query=new WP_Query($args);
                    if($query->have_posts()):
                        while($query->have_posts()):$query->the_post();
                            $postid=$query->post->ID;

                            $discount_rate = get_field( 'discount_rate', $postid );
                            $duration = get_field(  'duration',$postid );
                            $min_price = get_field( 'price_per_person', $postid );
                            $brief = get_the_excerpt($postid);
                            $field = get_field_object('location',$postid);
                            $value = $field['value'];
                            $location=$value->name;

                            ?>
                            <li class="grid-cards__item">


                                <a href="<?php the_permalink();?>" target="_self"
                                   class="offer-card" data-offer-id="106215" data-js-component="offerCard">

                                    <div data-src="<?php the_post_thumbnail_url();?>" class="offer-card__image b-lazy" style="background-image: url('<?php the_post_thumbnail_url();?>')">

                <span class="js-button-favorite" data-offer-id="106215" data-favorited="0" data-shape="offercard">
                   <button class="button-favorite">
                    <svg class="button-favorite__icon">
                       <use xlink:href="#heart" />
                    </svg>
                    <svg class="button-favorite__icon button-favorite__icon--overlay">
                       <use xlink:href="#heart-border" />
                    </svg>
                   </button>
                </span>

                                    </div>

                                    <div class="offer-card__info">
                                        <h4 class="offer-card__title"><?php the_title();?></h4>
                                        <ul class="list list--horizontal">

                                            <li class="list__item"><i class="soap-icon-clock yellow-color"></i> <?php echo esc_html($duration);?></li>
                                            <!--                                    <li class="list__item"></li>-->
                                        </ul>
                                        <!--                                <ul class="offer-icons">-->
                                        <!--                                    <li class="offer-icons__item js-tooltip tooltip">-->
                                        <!--                                        <svg class="offer-icons__icon">-->
                                        <!--                                            <use xlink:href="#hotel" />-->
                                        <!--                                        </svg>-->
                                        <!--                                        <span class="tooltip__content js-tooltip-content">Med indkvartering</span>-->
                                        <!--                                    </li>-->
                                        <!--                                </ul>-->

                                        <div class="offer-card__price-wrap">
                                            <span class="offer-card__price-from">Price </span>
                                            <span class="offer-card__price-value">NPR.<?php echo  $min_price; ?>-</span>
                                            <!--                                    <span class="price-info tooltip js-tooltip" data-bi-event="extra_info_tooltip"-->
                                            <!--                                          data-tooltip-url="/offer/106215/extra_info/?show_price_for_interval=1">-->
                                            <!--                    <svg class="price-info__icon">-->
                                            <!--                        <use xlink:href="#info" />-->
                                            <!--                    </svg>-->
                                            <span class="tooltip__content js-tooltip-content"></span>
                                            </span>
                                        </div>

                                        <ul class="list list--horizontal list--small">
                                            <li class="list__item">Cost per person </li>
                                            <li class="list__item"><?php echo $location;?></li>
                                        </ul>
                                    </div>
                                </a>
                            </li>

                            <?php
                        endwhile;
                    else :
                        ?>
                        <li class="grid-cards__item">

                            <h3>No Trekkings Available.</h3>

                        </li>
                        <?php
                        // Restore original Post Data
                        wp_reset_postdata();
                    endif;
                    ?>
                </ul>
            </section>




            <ul class="category-card-list">
                <?php
                $args2=array(
                    'post_type'=>'post',
                    'posts_per_page'=>'9',
                );
                $query2=new WP_Query($args2);
                if($query2->have_posts()):
                    $i=0;
                    while($query2->have_posts()):$query2->the_post();
                    $post_id=$query2->post->ID;
                    $image=get_the_post_thumbnail_url($post_id);

                        if($i==0 || $i==3 || $i==8):
                    ?>
                        <li class="category-card-list__item category-card-list__item--2">
                    <a href="storbyferie/index.html" class="category-card">
                        <picture class="category-card__image-wrapper">

                            <img class="category-card__image b-lazy" src="<?php echo $image;?>">
                        </picture>
                        <span class="category-card__title"><?php the_title();?> </span>
<!--                       <span class="category-card__subtitle">Hvilken storby er jeres favorit?</span>-->
                    </a>
                </li>
                        <?php
                        elseif($i==1 || $i==2 || $i==4 || $i==5 || $i==6 ||$i==7):
                            ?>
                            <li class="category-card-list__item category-card-list__item--1">
                                <a href="charterrejser/index.html" class="category-card">
                                    <picture class="category-card__image-wrapper">

                                        <img class="category-card__image b-lazy" src="<?php echo $image;?>">

                                    </picture>
                                    <span class="category-card__title"><?php the_title();?> </span>
<!--                                    <span class="category-card__subtitle">Sol, strand og sand mellem tæerne</span>-->
                                </a>
                            </li>


                            <?php

                        endif;
                       $i++;
                endwhile;

                    endif;
                ?>
            </ul>
            <ul class="category-card-list category-card-list--static">
                <li class="category-card-list__item category-card-list__item--half">
                    <a href="friends/tell-a-friend/indexdbec.html?trck=homepage" class="category-card category-card--referral">
                        <div class="category-card__images">

                            <picture class="category-card__image-wrapper">
                                <source srcset="//d3sxhanqns5a1i.cloudfront.net/static/img/referrals/v2/friends-home-bg-S@2x.a02dc3c1857a.png 2x, //d3sxhanqns5a1i.cloudfront.net/static/img/referrals/v2/friends-home-bg-S@2x.a02dc3c1857a.png 1x" media="(max-width: 767px)">
                                <source srcset="//d3sxhanqns5a1i.cloudfront.net/static/img/referrals/v2/friends-home-bg-M@2x.26f32fcedd43.png 2x, //d3sxhanqns5a1i.cloudfront.net/static/img/referrals/v2/friends-home-bg-M@2x.26f32fcedd43.png 1x" media="(min-width: 767px) and (max-width: 1023px)">
                                <source srcset="//d3sxhanqns5a1i.cloudfront.net/static/img/referrals/v2/friends-home-bg-L@2x.a1ad982af9ad.png 2x, //d3sxhanqns5a1i.cloudfront.net/static/img/referrals/v2/friends-home-bg-L@2x.a1ad982af9ad.png 1x" media="(min-width: 1024px)">
                                <img class="category-card__image" src="../d3sxhanqns5a1i.cloudfront.net/static/img/referrals/v2/friends-home-bg-L%402x.a1ad982af9ad.png">

                            </picture>
                            <div class="category-card__referral-wrap">
                                <svg class="category-card__referral-icon">
                                    <use xlink:href="#referral" />
                                </svg>
                                <span class="category-card__referral-title">Giv 200 DKK til dine venner</span>
                            </div>
                        </div>
                        <span class="category-card__title">Inviter venner</span>
                    </a>
                </li>
                <li class="category-card-list__item category-card-list__item--half">
                    <a href="app/index.html" class="category-card">
                        <picture class="category-card__image-wrapper">
                            <source srcset="https://travelbird-static.imgix.net/static/img/2016/category-cards/AppCard_large@2x.468bc93e43fb.jpg?auto=compress%2Cformat&crop=faces%2Cedges%2Ccenter&dpr=2&fit=crop&h=704&w=1088 2x, https://travelbird-static.imgix.net/static/img/2016/category-cards/AppCard_large@2x.468bc93e43fb.jpg?auto=compress%2Cformat&crop=faces%2Cedges%2Ccenter&dpr=1&fit=crop&h=704&w=1088 1x"
                                    data-srcset="https://travelbird-static.imgix.net/static/img/2016/category-cards/AppCard_large@2x.468bc93e43fb.jpg?auto=compress%2Cformat&crop=faces%2Cedges%2Ccenter&dpr=2&fit=crop&h=704&w=1088 2x, https://travelbird-static.imgix.net/static/img/2016/category-cards/AppCard_large@2x.468bc93e43fb.jpg?auto=compress%2Cformat&crop=faces%2Cedges%2Ccenter&dpr=1&fit=crop&h=704&w=1088 1x"  media="(min-width: 1024px)">

                            <source srcset="https://travelbird-static.imgix.net/static/img/2016/category-cards/AppCard_medium@2x.10b8ec754617.jpg?auto=compress%2Cformat&crop=faces%2Cedges%2Ccenter&dpr=2&fit=crop&h=704&w=704 2x, https://travelbird-static.imgix.net/static/img/2016/category-cards/AppCard_medium@2x.10b8ec754617.jpg?auto=compress%2Cformat&crop=faces%2Cedges%2Ccenter&dpr=1&fit=crop&h=704&w=704 1x"
                                    data-srcset="https://travelbird-static.imgix.net/static/img/2016/category-cards/AppCard_medium@2x.10b8ec754617.jpg?auto=compress%2Cformat&crop=faces%2Cedges%2Ccenter&dpr=2&fit=crop&h=704&w=704 2x, https://travelbird-static.imgix.net/static/img/2016/category-cards/AppCard_medium@2x.10b8ec754617.jpg?auto=compress%2Cformat&crop=faces%2Cedges%2Ccenter&dpr=1&fit=crop&h=704&w=704 1x"  media="(min-width: 768px)">

                            <source srcset="https://travelbird-static.imgix.net/static/img/2016/category-cards/AppCard_small@2x.e6bb5b9f48b5.jpg?auto=compress%2Cformat&crop=faces%2Cedges%2Ccenter&dpr=2&fit=crop&h=456&w=608 2x, https://travelbird-static.imgix.net/static/img/2016/category-cards/AppCard_small.c1fd207963e6.jpg?auto=compress%2Cformat&crop=faces%2Cedges%2Ccenter&dpr=1&fit=crop&h=456&w=608 1x"
                                    data-srcset="https://travelbird-static.imgix.net/static/img/2016/category-cards/AppCard_small@2x.e6bb5b9f48b5.jpg?auto=compress%2Cformat&crop=faces%2Cedges%2Ccenter&dpr=2&fit=crop&h=456&w=608 2x, https://travelbird-static.imgix.net/static/img/2016/category-cards/AppCard_small.c1fd207963e6.jpg?auto=compress%2Cformat&crop=faces%2Cedges%2Ccenter&dpr=1&fit=crop&h=456&w=608 1x" media="(max-width: 767px)">
                            <img class="category-card__image b-lazy" src="../travelbird-static.imgix.net/static/img/2016/category-cards/AppCard_large.f1eab96f6dc4c0c0.jpg?auto=compress%2Cformat&amp;crop=faces%2Cedges%2Ccenter&amp;fit=crop&amp;h=704&amp;w=1088" data-src="https://travelbird-static.imgix.net/static/img/2016/category-cards/AppCard_large.f1eab96f6dc4.jpg?auto=compress%2Cformat&crop=faces%2Cedges%2Ccenter&fit=crop&h=704&w=1088" alt="">
                        </picture>
                        <span class="category-card__title">Apps</span>
                        <span class="category-card__subtitle">Din sekretær og rejseledsager</span>
                    </a>
                </li>
            </ul>        </section>

        <section class="wrap">
            <a href="https://help.travelbird.com/hc/da" class="helpdesk">
                <svg class="helpdesk__icon">
                    <use xlink:href="#helpdesk" />
                </svg>
                <div class="helpdesk__content">
                    <div class="helpdesk__text-wrap">
                        <span class="helpdesk__title">Kan vi hjælpe dig?</span>
                        <span class="helpdesk__text">Find svar på de oftest stillede spørgsmål eller kontakt os.</span>
                    </div>
                    <span class="helpdesk__link">Til kundeservice</span>
                </div>
            </a>
        </section>
<!--        <section>-->
<!--            --><?php
//                if(have_posts()):
//                    while(have_posts()):the_post();
//                the_content();
//                endwhile;
//                    endif;
//                    ?>
<!--        </section>-->
    </main>
<?php

get_footer();